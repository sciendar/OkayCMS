
<p>
    <?=$lang->terms_of_use?>:
    <pre class="license_wrap"><p><?=$lang->text_license?></p></pre>
</p>
<div class="clear"></div>
<form method="GET" class="clearfix">
    <input name="route" type="hidden" value="Step_2" />
    <input type="submit" class="next_step_button" value="<?=$lang->next_step?>" />
</form>
<div class="clear"></div>
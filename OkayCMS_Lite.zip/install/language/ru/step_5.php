<?php
// Heading
$_['meta_title']                            = 'Лицензионный ключ';
$_['title_h1']                              = 'Лицензионный ключ';

// Text
$_['for_work_okay_cms']                     = 'Для работы OkayCMS необходим лицензионный ключ';
$_['get_test_license']                      = 'Получить тестовый ключ';
$_['next_step']                             = 'Продолжить';
$_['thanks_for_license']                    = 'Благодарим вас за использование лицензионной версии OkayCMS!';
$_['license_date_text']                     = 'Ваша лицензия действительна до:';

// Error
$_['error_check_license']                   = 'Лицензия недействительна';
$_['error_config_file_not_writable']        = 'Поставьте права на запись для файла config/config.php';

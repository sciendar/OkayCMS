<?php
// Heading
$_['project_homepage']                      = 'Главная страница проекта';
$_['documentation']                         = 'Документация';
$_['support_forum']                         = 'Форум поддержки клиентов';
$_['system_version']                        = 'Версия: ';
$_['install_lang']                          = 'Язык установки';

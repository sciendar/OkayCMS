<?php
// Heading
$_['meta_title']            = 'Распаковка архива';
$_['title_h1']              = 'Распаковка архива';

// Text
$_['zip_unzipped']          = 'Архив успешно распакован в папку <b>{$dir}</b>';
$_['next_step']             = 'Далее';

// Error
$_['zip_file_not_found']    = 'Файл okaycms.zip не найден!';
$_['can_not_unzip']         = 'Не удалось распаковать архив!';

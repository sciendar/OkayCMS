<?php
// Heading
$_['meta_title']                            = 'Установка завершена успешно';
$_['title_h1']                              = 'Установка завершена успешно';

// Text
$_['front']                                 = 'Адрес вашего сайта';
$_['backend']                               = 'Панель управления';
$_['thanks_for_okay_cms']                   = 'Приятной работы с OkayCMS!';

// Error
$_['error_delete_source']                   = 'Обязательно удалите папку /install';
<?php
// Heading
$_['meta_title']                            = 'Installation completed successfully';
$_['title_h1']                              = 'Installation completed successfully';

// Text
$_['front']                                 = 'The address of your site';
$_['backend']                               = 'Control Panel';
$_['thanks_for_okay_cms']                   = 'Pleasant work with OkayCMS!';

// Error
$_['error_delete_source']                   = 'Be sure to delete the /install folder';
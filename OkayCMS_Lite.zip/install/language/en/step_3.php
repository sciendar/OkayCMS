<?php
// Heading
$_['meta_title']            = 'Unpacking the archive';
$_['title_h1']              = 'Unpacking the archive';

// Text
$_['zip_unzipped']          = 'The archive was successfully unpacked in the folder <b> {$dir} </b>';
$_['next_step']             = 'Next';

// Error
$_['zip_file_not_found']    = 'Okaycms.zip file not found!';
$_['can_not_unzip']         = 'Unable to unpack the archive!';

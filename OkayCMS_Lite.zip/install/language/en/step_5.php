<?php
// Heading
$_['meta_title']                            = 'License key';
$_['title_h1']                              = 'License key';

// Text
$_['for_work_okay_cms']                     = 'OkayCMS requires a license key';
$_['get_test_license']                      = 'Get the test key';
$_['next_step']                             = 'Continue';
$_['thanks_for_license']                    = 'Thank you for using the licensed version of OkayCMS!';
$_['license_date_text']                     = 'Your license is valid until';

// Error
$_['error_check_license']                   = 'License is not valid';
$_['error_config_file_not_writable']        = 'Set the write permissions for config/config.php';

<?php
// Heading
$_['project_homepage']                      = 'Project Homepage';
$_['documentation']                         = 'Documentation';
$_['support_forum']                         = 'Support Forum';
$_['system_version']                        = 'Version: ';
$_['install_lang']                          = 'Language wizard';
